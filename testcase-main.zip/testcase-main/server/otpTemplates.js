/**
 * WhatsApp OTP message builder.
 *
 * WaSenderAPI drives an ordinary WhatsApp session rather than the official
 * Business API, and sending identical text on every request is an obvious bot
 * fingerprint. So a message is assembled from interchangeable parts — a
 * structural layout plus randomly chosen header, greeting, lead-in, code line,
 * validity phrasing, warning and footer. A handful of fixed templates would
 * give a handful of shapes; mixing the parts gives millions.
 *
 * Sized for ~50,000 sends: every slot below multiplies the space, so no single
 * shape should repeat more than a couple of times across the whole user base.
 *
 * Every generated message, whatever the combination, always contains:
 *   - the brand name
 *   - the code, in *bold*, on its own visual line
 *   - how long the code lasts
 *   - a warning not to share it
 *
 * Formatting uses WhatsApp markup: *bold*, _italic_.
 *
 * Deliberately NOT used: zero-width characters, homoglyphs (Cyrillic
 * lookalikes) or other invisible-noise tricks. They break screen readers and
 * copy-paste of the code, and are themselves a spam signal.
 */

import crypto from 'node:crypto';
import { isPublicHttpsUrl, publicAssetUrl } from './publicUrl.js';

const BRAND = 'Sathyam Agro Mart';

// The sign-up code is sent as the caption of this banner: the brand as it
// appears at the top of the sign-in card. Rebuild it with
// server/scripts/build-otp-banner.mjs. OTP_BANNER_URL may point at another
// image. Returns null, meaning text only, when there is no public HTTPS
// address for it (local development).
export const OTP_BANNER_PATH = '/assets/whatsapp-otp-banner.png';
// WhatsApp keeps a copy of an image per URL, so a new banner at the same
// address still arrives as the old picture. The URL carries the first 12 hex
// characters of the file's SHA-256; build-otp-banner.mjs prints the new value
// and tests/otp-banner.test.mjs fails if it is left stale.
export const OTP_BANNER_VERSION = 'c5813e7d131b';

export function otpBannerUrl() {
  const override = String(process.env.OTP_BANNER_URL || '').trim();
  if (!override) return publicAssetUrl(`${OTP_BANNER_PATH}?v=${OTP_BANNER_VERSION}`);
  if (isPublicHttpsUrl(override)) return override;
  console.warn('⚠️ OTP_BANNER_URL is not a public HTTPS URL, so sign-up codes are sent as text.');
  return null;
}

// WhatsApp cuts image captions off after this many characters.
export const WHATSAPP_CAPTION_LIMIT = 1024;

const pick = (arr) => arr[crypto.randomInt(0, arr.length)];
const maybe = (value, chance = 0.5) => (crypto.randomInt(0, 100) < chance * 100 ? value : '');

// Lowercases the opening word so a sentence reads correctly after a greeting
// comma: "Dear Stephan, to continue…" rather than "…, To continue".
const decap = (s) => s.charAt(0).toLowerCase() + s.slice(1);

// ---------------------------------------------------------------
// Interchangeable wording
// ---------------------------------------------------------------

// One emoji leads each fact line, so the message is easy to scan: the time
// the code lasts, the warning, the line before the code. Each is picked from
// a small set, like the wording, so the look varies from message to message.
const TIME_EMOJI = ['⏳', '⏱️', '🕒']
const WARN_EMOJI = ['🔒', '🚫', '⚠️']
const LEAD_EMOJI = ['🔐', '🔑', '✅']
const CODE_EMOJI = ['👉', '➡️']
const withEmoji = (emojis, text) => `${pick(emojis)} ${text}`

const GREETINGS = [
  (n) => `Hello ${n},`,
  (n) => `Hello ${n} 👋`,
  (n) => `Hi ${n},`,
  (n) => `Dear ${n},`,
  (n) => `${n},`,
  (n) => `Hey ${n},`,
  (n) => `Welcome ${n},`,
  (n) => `Greetings ${n},`,
  (n) => `Vanakkam ${n},`,
  (n) => `Vanakkam ${n} 🙏`,
  (n) => `Hello there, ${n},`,
  (n) => `${n} 🌾`,
];

const LEAD_INS = [
  'Use this code to verify your mobile number:',
  'Here is the verification code you requested:',
  'Your one-time password is:',
  'Please use the code below to confirm your number:',
  'To continue, enter this verification code:',
  'This is the code for your mobile verification:',
  'Confirm your mobile number with the code below:',
  'Here is your one-time verification code:',
  'Enter the code below to finish verifying your number:',
  'The verification code for your account is:',
  'Please confirm your mobile number using this code:',
  'Your verification code is ready:',
  'Use the code below to complete your sign-up:',
  'To finish signing up, enter this code:',
];

const CODE_LINES = [
  (otp) => `*${otp}*`,
  (otp) => `Code: *${otp}*`,
  (otp) => `Your code: *${otp}*`,
  (otp) => `➡️ *${otp}*`,
  (otp) => `🔐 *${otp}*`,
  (otp) => `*${otp}* 🔑`,
];

const VALIDITY_TEXT = [
  (m) => `Valid for ${m} minutes.`,
  (m) => `It expires in ${m} minutes.`,
  (m) => `This code stops working after ${m} minutes.`,
  (m) => `Please enter it within ${m} minutes.`,
  (m) => `The code is active for the next ${m} minutes.`,
  (m) => `You have ${m} minutes to use this code.`,
  (m) => `Use it within ${m} minutes.`,
  (m) => `This code is valid for the next ${m} minutes only.`,
  (m) => `It will expire ${m} minutes from now.`,
  (m) => `Please use it before ${m} minutes are up.`,
  (m) => `Good for ${m} minutes.`,
  (m) => `The code lasts ${m} minutes.`,
];

const WARNING_TEXT = [
  'Never share this code with anyone.',
  `Do not forward this code. ${BRAND} staff will never ask you for it.`,
  'Keep this code private — sharing it puts your account at risk.',
  `Anyone asking you for this code is not from ${BRAND}.`,
  'For your safety, never pass this code on.',
  'Treat this code like a password and keep it to yourself.',
  'Please do not share this code, not even with family.',
  `${BRAND} will never call or message you asking for this code.`,
  'This code is meant only for you — keep it private.',
  'Sharing this code could let someone else access your account.',
  'Never send this code to anyone who asks for it.',
  'Keep this code secret to protect your account.',
];

// With their emoji. A layout that puts two facts on one line reads fine too:
// "⏳ Valid for 5 minutes. 🔒 Never share this code with anyone."
const VALIDITY = VALIDITY_TEXT.map((line) => (m) => withEmoji(TIME_EMOJI, line(m)))
const warning = () => withEmoji(WARN_EMOJI, pick(WARNING_TEXT))

const FOOTERS = [
  '_If you did not request this, you can safely ignore this message._',
  '_Not you? No action is needed — simply ignore this message._',
  `_This is an automated message from ${BRAND}._`,
  '_Did not request a code? You can ignore this message._',
  '_If this was not you, no further action is required._',
  '_This message was sent because someone entered this number to sign up._',
  `_Need help? Contact ${BRAND} support._`,
  '_You are receiving this because a verification was requested._',
];

const HEADERS = [
  `*${BRAND}* — Mobile Verification`,
  `*${BRAND}* account verification`,
  `🌾 *${BRAND}* — verify your number`,
  `*${BRAND}* security check`,
  `🌱 *${BRAND}*`,
  `*${BRAND}* — one-time password`,
  `*${BRAND}* — confirm your number`,
  `🔐 *${BRAND}* verification`,
  `*${BRAND}* sign-up verification`,
  `*${BRAND}* — verification code`,
  `🌿 *${BRAND}* account security`,
  `*${BRAND}* | Mobile number check`,
];

// ---------------------------------------------------------------
// Structural layouts
// Each returns an array of lines; '' becomes a blank line.
// Every layout draws on several slots above so none is a narrow, easily
// repeated shape.
// ---------------------------------------------------------------

const LAYOUTS = [
  // 1 — header, greeting, lead, code, details, footer
  ({ name, otp, mins, lead, footer, header }) => [
    header(), '',
    pick(GREETINGS)(name),
    lead(), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    warning(),
    maybe('\n' + footer(), 0.5),
  ],

  // 2 — code first, then explanation
  ({ name, otp, mins, lead, footer, header }) => [
    `*${otp}* is your *${BRAND}* verification code.`, '',
    `${pick(GREETINGS)(name)} ${decap(lead().replace(/:$/, '.'))}`,
    pick(VALIDITY)(mins), '',
    `${pick(WARN_EMOJI)} _${pick(WARNING_TEXT)}_`,
    maybe('\n' + footer(), 0.3),
  ],

  // 3 — compact, brand inline
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name),
    `Your *${BRAND}* code is *${otp}*.`,
    `${pick(VALIDITY)(mins)} ${warning()}`,
    maybe('\n' + footer(), 0.4),
  ],

  // 4 — labelled block
  ({ name, otp, mins, lead, footer, header }) => [
    header(), '',
    pick(GREETINGS)(name), '',
    `Verification code: *${otp}*`,
    withEmoji(TIME_EMOJI, `Valid for: ${mins} minutes`), '',
    warning(),
    maybe('\n' + footer(), 0.4),
  ],

  // 5 — greeting first, brand as sign-off
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name), '',
    lead(), '',
    pick(CODE_LINES)(otp), '',
    `${warning()} ${pick(VALIDITY)(mins)}`, '',
    `— *${BRAND}*`,
  ],

  // 6 — short, header-led
  ({ otp, mins, lead, footer, header }) => [
    header(), '',
    pick(CODE_LINES)(otp), '',
    `${pick(VALIDITY)(mins)} ${warning()}`,
    maybe('\n' + footer(), 0.5),
  ],

  // 7 — welcoming tone
  ({ name, otp, mins, lead, footer, header }) => [
    `${pick(GREETINGS)(name)} welcome to *${BRAND}* 🌱`, '',
    lead(), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    warning(),
    maybe('\n' + footer(), 0.3),
  ],

  // 8 — header, code, details on separate lines
  ({ otp, mins, lead, footer, header }) => [
    header(), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    warning(),
    maybe('\n' + footer(), 0.6),
  ],

  // 9 — sentence style, code inline
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name),
    `Please enter *${otp}* to verify your mobile number with *${BRAND}*.`,
    pick(VALIDITY)(mins), '',
    warning(),
    maybe('\n' + footer(), 0.4),
  ],

  // 10 — bulleted details
  ({ name, otp, mins, lead, footer, header }) => [
    header(), '',
    pick(GREETINGS)(name), '',
    pick(CODE_LINES)(otp), '',
    `• ${pick(VALIDITY)(mins)}`,
    '• Can be used once',
    `• ${warning()}`,
  ],

  // 11 — question opener
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name),
    `Signing up with *${BRAND}*?`,
    lead(), '',
    pick(CODE_LINES)(otp), '',
    `${pick(VALIDITY)(mins)} ${warning()}`,
    maybe('\n' + footer(), 0.3),
  ],

  // 12 — footer-branded
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name), '',
    lead(), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    warning(), '',
    `— *${BRAND}*`,
  ],

  // 13 — warning emphasised first
  ({ name, otp, mins, lead, footer, header }) => [
    header(), '',
    pick(GREETINGS)(name),
    `${warning()}`, '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    maybe('\n' + footer(), 0.4),
  ],

  // 14 — two-line body, footer required
  ({ name, otp, mins, lead, footer, header }) => [
    `${pick(GREETINGS)(name)} ${decap(lead())}`, '',
    pick(CODE_LINES)(otp), '',
    `${pick(VALIDITY)(mins)} ${warning()}`, '',
    `— *${BRAND}*`,
    footer(),
  ],

  // 15 — brand header plus closing signature
  ({ name, otp, mins, lead, footer, header }) => [
    header(), '',
    pick(GREETINGS)(name),
    lead(), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins), '',
    `${pick(WARN_EMOJI)} _${pick(WARNING_TEXT)}_`, '',
    `— *${BRAND}*`,
  ],

  // 16 — minimal, single detail line
  ({ name, otp, mins, lead, footer, header }) => [
    pick(GREETINGS)(name),
    lead(), '',
    `*${otp}*`, '',
    `${pick(VALIDITY)(mins)} ${warning()}`, '',
    `*${BRAND}*`,
  ],
];

// Remembers the last layout used per number, so a resend never arrives in the
// same shape the user just received.
const lastLayout = new Map();

export function forgetOtpLayout(phone) {
  lastLayout.delete(phone);
}

/**
 * The name comes from a user-filled form, so it may be blank, a phone number,
 * or junk. Never address someone as a string of digits.
 */
export function safeFirstName(userName) {
  const first = String(userName || '').trim().split(/\s+/)[0] || '';
  const letters = first.replace(/[^\p{L}\p{M}]/gu, '');
  if (letters.length < 2) return 'Farmer';
  return first.slice(0, 24);
}

// ---------------------------------------------------------------
// Tamil, above the English
// Customers read Tamil first; the English below carries the same facts. The
// Tamil lines vary as the English ones do, so the message never settles into
// one fixed shape.
// ---------------------------------------------------------------

const TA_BRAND = 'சத்யம் அக்ரோ மார்ட்'
// Used when there is no usable name ("Farmer" in English).
const TA_NO_NAME = 'விவசாயி நண்பரே'

const TA_GREETINGS = [
  (n) => `வணக்கம் ${n} 🙏`,
  (n) => `வணக்கம் ${n},`,
  (n) => `அன்புள்ள ${n},`,
  (n) => `வணக்கம் ${n} 🌾`,
]

// A new customer is welcomed; a returning one is welcomed back.
const TA_WELCOME = [
  `*${TA_BRAND}*-க்கு உங்களை அன்புடன் வரவேற்கிறோம் 🌱`,
  `*${TA_BRAND}* குடும்பத்திற்கு உங்களை வரவேற்கிறோம் 🌾`,
  `*${TA_BRAND}*-இல் இணைந்ததற்கு நன்றி 🌱`,
]
const TA_WELCOME_BACK = [
  'மீண்டும் வருக! 🌾',
  'உங்களை மீண்டும் காண்பதில் மகிழ்ச்சி 🌱',
  `*${TA_BRAND}*-க்கு மீண்டும் வருக 🌿`,
]

const TA_LEAD_INS = [
  'உங்கள் சரிபார்ப்புக் குறியீடு:',
  'உங்கள் ஒருமுறை கடவுச்சொல் (OTP):',
  'கீழே உள்ள குறியீட்டை உள்ளிடுங்கள்:',
  'உங்கள் எண்ணை உறுதிப்படுத்த இந்தக் குறியீடு:',
]

const TA_VALIDITY = [
  (m) => `இந்தக் குறியீடு ${m} நிமிடங்களுக்கு மட்டுமே செல்லும்.`,
  (m) => `${m} நிமிடங்களுக்குள் பயன்படுத்துங்கள்.`,
  (m) => `இது ${m} நிமிடங்களில் காலாவதியாகும்.`,
]

const TA_WARNINGS = [
  'இந்தக் குறியீட்டை யாரிடமும் பகிர வேண்டாம்.',
  'எங்கள் ஊழியர்கள் ஒருபோதும் இந்தக் குறியீட்டைக் கேட்க மாட்டார்கள்.',
  'உங்கள் பாதுகாப்புக்காக இதை ரகசியமாக வைத்திருங்கள்.',
]

// Asked once, on the first message: a customer who saves the number is far
// less likely to report it, and WhatsApp trusts a saved contact.
const TA_SAVE = [
  `📌 ஆர்டர் விவரங்களும் விவசாய ஆலோசனைகளும் தவறாமல் கிடைக்க, இந்த எண்ணை *${BRAND}* என்று சேமித்துக்கொள்ளுங்கள்.`,
  `📌 இந்த எண்ணை *${BRAND}* என்று உங்கள் தொடர்புகளில் சேமியுங்கள்; ஆர்டர் தகவல்கள் இதே எண்ணில் வரும்.`,
]
const EN_SAVE = [
  `📌 Save this number as *${BRAND}* so you never miss order updates and crop tips.`,
  `📌 Please save this number as *${BRAND}* — your order updates will come from here.`,
  `📌 Add this number to your contacts as *${BRAND}* to keep getting order updates.`,
]

function tamilBlock({ name, otp, mins, isNew }) {
  const who = name === 'Farmer' ? TA_NO_NAME : name
  return [
    pick(TA_GREETINGS)(who),
    pick(isNew ? TA_WELCOME : TA_WELCOME_BACK), '',
    withEmoji(LEAD_EMOJI, pick(TA_LEAD_INS)),
    `${pick(CODE_EMOJI)} *${otp}*`, '',
    withEmoji(TIME_EMOJI, pick(TA_VALIDITY)(mins)),
    withEmoji(WARN_EMOJI, pick(TA_WARNINGS)),
    isNew ? '\n' + pick(TA_SAVE) : '',
  ]
}

// Wording that only makes sense while signing up.
const SIGN_UP_WORDING = /sign.?up|signing up/i
// Layouts 7 ("welcome to") and 11 ("Signing up with") are for new customers.
const NEW_CUSTOMER_LAYOUTS = new Set([6, 10])

const clean = (lines) => lines
  .filter((line) => line !== null && line !== undefined)
  .join('\n')
  .replace(/\n{3,}/g, '\n\n')
  .trim()

/**
 * The sign-in code for a customer: Tamil first, then English.
 * isNew: a number with no account yet - welcomed, and asked to save the number.
 * A returning customer is welcomed back and reads no sign-up wording.
 */
export function buildOtpMessage(otp, userName = 'Farmer', phone = '', expiryMs = 5 * 60 * 1000, { isNew = true } = {}) {
  const mins = Math.round(expiryMs / 60000);
  const name = safeFirstName(userName);

  const previous = lastLayout.get(phone);
  const choices = LAYOUTS.map((_, i) => i).filter((i) => i !== previous && (isNew || !NEW_CUSTOMER_LAYOUTS.has(i)));
  const index = choices[crypto.randomInt(0, choices.length)];
  if (phone) lastLayout.set(phone, index);

  const leadIns = isNew ? LEAD_INS : LEAD_INS.filter((line) => !SIGN_UP_WORDING.test(line));
  const footers = isNew ? FOOTERS : FOOTERS.filter((line) => !SIGN_UP_WORDING.test(line));
  const headers = isNew ? HEADERS : HEADERS.filter((line) => !SIGN_UP_WORDING.test(line));
  const english = clean(LAYOUTS[index]({ name, otp, mins, lead: () => pick(leadIns), footer: () => pick(footers), header: () => pick(headers) }));

  return clean([
    clean(tamilBlock({ name, otp, mins, isNew })), '',
    '━━━━━━━━━━', '',
    english,
    isNew ? '\n' + pick(EN_SAVE) : '',
  ]);
}

export const OTP_LAYOUT_COUNT = LAYOUTS.length;

// ---------------------------------------------------------------
// Password reset codes
// The sign-up layouts talk about verifying a number or signing up, which is
// wrong for a reset. Reset messages share the greeting, code, validity and
// warning pools but have their own headers, lead-ins and footers.
// ---------------------------------------------------------------

const RESET_HEADERS = [
  `*${BRAND}* — password reset`,
  `🔐 *${BRAND}* password reset`,
  `*${BRAND}* — reset your password`,
  `🌿 *${BRAND}* account security`,
  `*${BRAND}* | Password reset code`,
];

const RESET_LEAD_INS = [
  'Use this code to reset your password:',
  'Here is the code to set a new password:',
  'Enter this code to reset your account password:',
  'Your password reset code is:',
  'To choose a new password, enter this code:',
  'Use the code below to reset your password:',
];

const RESET_FOOTERS = [
  '_Did not ask to reset your password? Ignore this message — your password stays the same._',
  '_Not you? Your password has not been changed. You can safely ignore this._',
  `_Sent automatically by ${BRAND}. No reply needed._`,
  `_Need help? Call ${BRAND} support on +91 87786 13372._`,
];

const RESET_LAYOUTS = [
  ({ name, otp, mins }) => [
    pick(RESET_HEADERS), '',
    pick(GREETINGS)(name),
    pick(RESET_LEAD_INS), '',
    pick(CODE_LINES)(otp), '',
    pick(VALIDITY)(mins),
    warning(), '',
    pick(RESET_FOOTERS),
  ],
  ({ name, otp, mins }) => [
    `*${otp}* is your *${BRAND}* password reset code.`, '',
    `${pick(GREETINGS)(name)} ${pick(VALIDITY)(mins)}`, '',
    `${pick(WARN_EMOJI)} _${pick(WARNING_TEXT)}_`, '',
    pick(RESET_FOOTERS),
  ],
  ({ name, otp, mins }) => [
    pick(GREETINGS)(name), '',
    pick(RESET_LEAD_INS), '',
    pick(CODE_LINES)(otp), '',
    `• ${pick(VALIDITY)(mins)}`,
    '• Can be used once',
    `• ${warning()}`, '',
    `— *${BRAND}*`,
  ],
  ({ name, otp, mins }) => [
    pick(RESET_HEADERS), '',
    `${pick(GREETINGS)(name)} ${decap(pick(RESET_LEAD_INS))}`, '',
    pick(CODE_LINES)(otp), '',
    `${pick(VALIDITY)(mins)} ${warning()}`, '',
    pick(RESET_FOOTERS),
  ],
];

export function buildResetOtpMessage(otp, userName = 'Farmer', phone = '', expiryMs = 5 * 60 * 1000) {
  const mins = Math.round(expiryMs / 60000);
  const name = safeFirstName(userName);
  const key = `reset:${phone}`;

  const previous = lastLayout.get(key);
  const choices = RESET_LAYOUTS.map((_, i) => i).filter((i) => i !== previous);
  const index = choices[crypto.randomInt(0, choices.length)];
  if (phone) lastLayout.set(key, index);

  return RESET_LAYOUTS[index]({ name, otp, mins })
    .filter((line) => line !== null && line !== undefined)
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// Security notice sent after a successful reset.
export function buildPasswordChangedMessage(userName = 'Farmer', phone = '') {
  const name = safeFirstName(userName);
  const masked = phone ? `+91 ••••••${String(phone).slice(-4)}` : 'your number';
  return [
    `🔐 *${BRAND}* — password changed`, '',
    `${pick(GREETINGS)(name)} the password for the ${BRAND} account on ${masked} was just changed, and any other devices were signed out.`, '',
    `If this was not you, call ${BRAND} support on +91 87786 13372 right away.`,
  ].join('\n');
}
